const { expect } = require('chai');
const lottery = require('./Lottery.js');

describe('Lottery functionality', () => {
    it('buyLotteryTicket', () => {
        expect(() => lottery.buyLotteryTicket([], [], true)).to.throw();
        expect(() => lottery.buyLotteryTicket([10], 10, true)).to.throw();
        expect(() => lottery.buyLotteryTicket(10, [10], true)).to.throw();
        expect(() => lottery.buyLotteryTicket('0', '1', 'false')).to.throw();
        expect(() => lottery.buyLotteryTicket('0', 1, 'false')).to.throw();
        expect(() => lottery.buyLotteryTicket(0, '1', 'false')).to.throw();
        expect(() => lottery.buyLotteryTicket('0', '1', true)).to.throw();
        expect(() => lottery.buyLotteryTicket('0', '1', false)).to.throw();
        expect(() => lottery.buyLotteryTicket(0, 1, true)).to.throw();
        expect(() => lottery.buyLotteryTicket(-1, 0, true)).to.throw();
        expect(() => lottery.buyLotteryTicket(-1, 1, true)).to.throw();
        expect(() => lottery.buyLotteryTicket(1, 0, true)).to.throw();
        expect(() => lottery.buyLotteryTicket(1, 1, 'random')).to.throw();
        expect(() => lottery.buyLotteryTicket(1, 0, false)).to.throw();
        expect(() => lottery.buyLotteryTicket(0, 1, false)).to.throw();
        expect(() => lottery.buyLotteryTicket(1, 1, false)).to.throw();
        expect(() => lottery.buyLotteryTicket(1, 1, true)).to.not.throw();
        expect(() => lottery.buyLotteryTicket(1, 1.1, false)).to.throw();
        expect(() => lottery.buyLotteryTicket(1, 1.1, true)).to.not.throw();
        expect(() => lottery.buyLotteryTicket(0.1, 1.1, true)).to.not.throw();
        expect(() => lottery.buyLotteryTicket(10, 10, true)).to.not.throw();
        expect(() => lottery.buyLotteryTicket(10.5, 10, true)).to.not.throw();

        expect(lottery.buyLotteryTicket(1, 1, true)).to.equal('You bought 1 tickets for 1$.');
        expect(lottery.buyLotteryTicket(1, 10, true)).to.equal('You bought 10 tickets for 10$.');
        expect(lottery.buyLotteryTicket(10, 10, true)).to.equal('You bought 10 tickets for 100$.');
        expect(lottery.buyLotteryTicket(10.3, 10, true)).to.equal('You bought 10 tickets for 103$.');
        const price = 10.1;
        const count = 10.1;
        const res = price * count;
        expect(res).to.be.closeTo(102.01, 0.0001);
        expect(lottery.buyLotteryTicket(10.3, 10, true)).to.equal('You bought 10 tickets for 103$.');
        expect(lottery.buyLotteryTicket(10.3333, 10.5, true)).to.equal('You bought 10.5 tickets for 108.49964999999999$.');
    });

    it('checkTicket', () => {
        expect(() => lottery.checkTicket('1, 2, 3, 4, 5, 6', '1, 2, 3, 4, 5, 6')).to.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5, 6], '1, 2, 3, 4, 5, 6')).to.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5, 6], '')).to.throw();
        expect(() => lottery.checkTicket('', '')).to.throw();
        expect(() => lottery.checkTicket('1, 2, 3, 4, 5, 6', [1, 2, 3, 4, 5, 6])).to.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5])).to.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5], [1, 2, 3, 4, 5, 6])).to.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5], [1, 2, 3, 4, 5])).to.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5], [1, 2, 3, 4, 5, 6, 7])).to.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6, 7])).to.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5, 6, 7], [1, 2, 3, 4, 5, 6, 7])).to.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5, '6'], [1, 2, 3, 4, 5, 6])).to.not.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5, '6'], [1, 2, 3, 4, 5, '6'])).to.not.throw();
        expect(() => lottery.checkTicket([1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6])).to.not.throw();
        expect(() => lottery.checkTicket([1], [1])).to.throw();
        expect(() => lottery.checkTicket([], [])).to.throw();
        expect(() => lottery.checkTicket(['1', '2', '3', '4', '5'], ['1', '2', '3', '4', '5', '6'])).to.throw();
        expect(() => lottery.checkTicket(['1', '2', '3', '4', '5', '6'], ['1', '2', '3', '4', '5', '6'])).to.not.throw();

        expect(lottery.checkTicket([1, 10, 9, 2, 23, 34], [1, 6, 0, 2, 3, 5])).to.be.undefined;
        expect(lottery.checkTicket([1, 10, 9, 2, 23, 34], [1, 6, 0, 18, 3, 5])).to.be.undefined;
        expect(lottery.checkTicket([1, 1, 1, 2, 3, 4], [1, 1, 0, 2, 3, 4])).to.equal(
            'Congratulations you win, check your reward!'
        );
        expect(lottery.checkTicket([1, 1, 1, 2, 3, 4], [1, 1, 1, 2, 3, 4])).to.equal(
            'Congratulations you win, check your reward!'
        );
        expect(lottery.checkTicket([1, 1, 1, 2, 3, 4], [1, 1, 1, 2, 3, 5])).to.equal(
            'Congratulations you win, check your reward!'
        );
        expect(lottery.checkTicket([1, 2, 3, 4, 5, 6], [1, 3, 1, 5, 3, 8])).to.equal(
            'Congratulations you win, check your reward!'
        );
        expect(lottery.checkTicket([1, 1, 1, 2, 3, 4], [1, 1, 1, 6, 3, 5])).to.be.undefined;
        expect(lottery.checkTicket([1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6])).to.equal('You win the JACKPOT!!!');
        expect(lottery.checkTicket([7, 8, 9, 10, 11, 12], [7, 8, 9, 10, 11, 12])).to.equal('You win the JACKPOT!!!');
        expect(lottery.checkTicket([7, 8, 9, 10, 11, 12], [7, 8, 9, 10, 11, '12'])).to.equal(
            'Congratulations you win, check your reward!'
        );
        expect(lottery.checkTicket([7, 8, 9, 10, 11, '12'], [7, 8, 9, 10, 11, '12'])).to.equal('You win the JACKPOT!!!');
        expect(lottery.checkTicket([1.1, 1.2, 1.3, 1.4, 1.5, 1.6], [1.1, 1.2, 1.3, 1.4, 1.5, 1.6])).to.equal(
            'You win the JACKPOT!!!'
        );
        expect(lottery.checkTicket([1.1, 1.2, 1.3, 1.4, 1.5, 1.6], [1.1, 1.2, 1.3, 1.4, 1.7, 1.8])).to.equal(
            'Congratulations you win, check your reward!'
        );
    });

    it('secondChance', () => {
        expect(() => lottery.secondChance('10', '10')).to.throw();
        expect(() => lottery.secondChance([10], 10)).to.throw();
        expect(() => lottery.secondChance([10], '10')).to.throw();
        expect(() => lottery.secondChance(10, '10')).to.throw();
        expect(() => lottery.secondChance(10, {})).to.throw();
        expect(() => lottery.secondChance({}, [])).to.throw();
        expect(() => lottery.secondChance(10, [10])).to.not.throw();
        expect(() => lottery.secondChance(10, [10])).to.not.throw();

        expect(lottery.secondChance(10, [10, 20, 30, 40, 50])).to.equal('You win our second chance prize!');
        expect(lottery.secondChance(40, [10, 20, 30, 40, 50])).to.equal('You win our second chance prize!');
        expect(lottery.secondChance(20.5, [10, 20.5, 30, 40, 50])).to.equal('You win our second chance prize!');
        expect(lottery.secondChance(60, [10, 20, 30, 40, 50])).to.equal("Sorry, your ticket didn't win!");
        expect(lottery.secondChance(15, [10, 20, 30, 40, 50])).to.equal("Sorry, your ticket didn't win!");
        expect(lottery.secondChance(15.5, [10, 20, 30.5, 40, 50])).to.equal("Sorry, your ticket didn't win!");

        expect(lottery.secondChance(10, ['10', 20, 30.5, 40, 50])).to.equal("Sorry, your ticket didn't win!");
        expect(lottery.secondChance(10, ['10'])).to.equal("Sorry, your ticket didn't win!");
        expect(lottery.secondChance(10, [])).to.equal("Sorry, your ticket didn't win!");
    });
});
