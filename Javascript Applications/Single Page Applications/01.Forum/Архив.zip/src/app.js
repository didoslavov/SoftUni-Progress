import { showHome } from './home.js';

document.getElementById('homeLink').addEventListener('click', showHome);

showHome();
